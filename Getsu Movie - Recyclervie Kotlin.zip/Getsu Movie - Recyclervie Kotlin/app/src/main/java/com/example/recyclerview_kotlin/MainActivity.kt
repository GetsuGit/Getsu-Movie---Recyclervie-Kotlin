package com.example.recyclerview_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val names = listOf<String>(
                    "Getsu",
                    "Design",
                    "Code",
                    "Getsu",
                    "Design",
                    "Code",
                    "Getsu",
                    "Design",
                    "Code",

        )

         val mainAdapter = MainAdapter( names)
        findViewById<RecyclerView>(R.id.recyclerView).adapter = mainAdapter
    }
}

